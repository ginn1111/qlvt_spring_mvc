
create PROCEDURE [dbo].[sp_SoLuongPhieuNhapTrongThang]
(@m varchar(02), @y varchar(4))
AS
	select number=count(*) from PHIEUNHAP
	where YEAR(THOIGIAN) = @y and MONTH(THOIGIAN) = @m
go

