CREATE PROCEDURE [dbo].[sp_SoLuongPhieuXuatTrongThang]
(@m varchar(02), @y varchar(4))
AS
	select number=count(*) from PHIEUXUAT
	where YEAR(THOIGIAN) = @y and MONTH(THOIGIAN) = @m


go

