create proc [dbo].[sp_getTopVatTuNhapTrongThang]
(@num smallint, @m varchar(02), @y varchar(4))
as
begin
	select top (@num) MAVATTU, SOLUONG
	from(
		select MAVATTU, SUM(SOLUONG) as SOLUONG
		from(
			select VATTU.MAVATTU as MAVATTU, CHITIETPHIEUNHAP.SOLUONG as SOLUONG
			from VATTU
			inner join CHITIETPHIEUNHAP on VATTU.MAVATTU = CHITIETPHIEUNHAP.MAVATTU
			inner join PHIEUNHAP on CHITIETPHIEUNHAP.MAPHIEUNHAP = PHIEUNHAP.MAPHIEUNHAP
			where YEAR(THOIGIAN) = @y and MONTH(THOIGIAN) = @m
		) as s
		group by MAVATTU
	) as s
	order by SOLUONG desc
end
go

