create proc [dbo].[sp_getTopVatTuXuatTrongThang]
(@num smallint, @m varchar(02), @y varchar(4))
as
begin
	select top (@num) MAVATTU, SOLUONG
	from(
		select MAVATTU, SUM(SOLUONG) as SOLUONG
		from(
			select VATTU.MAVATTU as MAVATTU, CHITIETPHIEUXUAT.SOLUONG as SOLUONG
			from VATTU
			inner join CHITIETPHIEUXUAT on VATTU.MAVATTU = CHITIETPHIEUXUAT.MAVATTU
			inner join PHIEUXUAT on CHITIETPHIEUXUAT.MAPHIEUXUAT = PHIEUXUAT.MAPHIEUXUAT
			where YEAR(THOIGIAN) = @y and MONTH(THOIGIAN) = @m
		) as s
		group by MAVATTU
	) as s
	order by SOLUONG desc
end
go

