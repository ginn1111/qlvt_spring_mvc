
CREATE PROCEDURE [dbo].[sp_SoLuongPhieuTraTrongThang]
(@m varchar(02), @y varchar(4))
AS
	select number=count(*) from PHIEUTRA
	where YEAR(NGAYTRA) = @y and MONTH(NGAYTRA) = @m

go

