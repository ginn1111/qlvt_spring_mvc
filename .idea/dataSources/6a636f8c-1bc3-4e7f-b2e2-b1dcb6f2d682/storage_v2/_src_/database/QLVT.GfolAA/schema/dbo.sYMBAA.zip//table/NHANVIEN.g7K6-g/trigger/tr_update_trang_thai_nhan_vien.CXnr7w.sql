
create trigger tr_update_trang_thai_nhan_vien on NHANVIEN
after update
as
begin
	declare @manv int
	select @manv=MANHANVIEN from inserted
	if update(TRANGTHAI)
	update TAIKHOAN set TRANGTHAI='false' where MANHANVIEN=@manv
end
go

