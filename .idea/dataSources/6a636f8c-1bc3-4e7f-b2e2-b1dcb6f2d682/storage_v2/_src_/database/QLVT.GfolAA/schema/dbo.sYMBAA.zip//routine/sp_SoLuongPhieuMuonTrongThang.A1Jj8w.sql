
CREATE PROCEDURE [dbo].[sp_SoLuongPhieuMuonTrongThang]
(@m int, @y int)
AS
	select number=count(*) from PHIEUMUON
	where YEAR(NGAYMUON) = @y and MONTH(NGAYMUON) = @m
go

