CREATE proc [dbo].[sp_get_job_of_emp_to_manager] @date date, @id_shift int
as
select id=convert(char(10), T.id_time_table)+convert(char(10),UT.id_up_task),
id_emp=IIF(id_emp_alter IS NULL, id_emp, id_emp_alter), job from udf_get_emp_of_shift(@date, @id_shift) T
inner join (select id_time_table, id_up_task from Work) W on W.id_time_table = T.id_time_table
inner join (select id_up_task, id_task from UpTasks) UT on UT.id_up_task = W.id_up_task
inner join (select id_task, job from Task) Task on Task.id_task = UT.id_task
order by id_emp

go

