
CREATE proc [dbo].[sp_statist_num_of_shift] @month int, @year int
as
begin
	
select id_emp=isnull(id_emp_alter, id_emp), id_time_table, id_shift
into #TT_TMP
from TimeTable 
where month(date) = @month AND year(date)=@year

select id_statist_num_of_shift=E.id_emp+name, E.id_emp, first_name, last_name, num_of_shift=count(E.id_emp), name
from (
		select *
		from Employee
		where active = 1
) E inner join #TT_TMP TT_TMP on TT_TMP.id_emp = E.id_emp
inner join 
(select id_shift, name from Shift where deleted='false') S on s.id_shift = TT_TMP.id_shift

group by E.id_emp, first_name, last_name, S.name
order by id_emp


drop table #TT_TMP

end
go

