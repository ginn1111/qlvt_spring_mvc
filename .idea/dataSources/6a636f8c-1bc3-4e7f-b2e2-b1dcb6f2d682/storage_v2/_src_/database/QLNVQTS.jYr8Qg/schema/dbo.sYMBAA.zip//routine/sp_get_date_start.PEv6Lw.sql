CREATE proc [dbo].[sp_get_date_start] @date_start date out
as
begin
	--delete from Constants where dateadd(day, 28, date_start) < getdate()
	declare @date_tmp date
	 select @date_tmp=max(date_start) from Constants
	select @date_start= isnull(min(date_start), @date_tmp)
	from Constants where dateadd(day, 21, date_start) >= getdate()
end
go

