

CREATE proc sp_loadmore_employees @loadmore int, @offset int
as
select * from Employee 
where active='true'
order by id_emp DESC
offset @loadmore row fetch next @offset row only

go

