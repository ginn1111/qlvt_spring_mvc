
CREATE view [dbo].[v_get_shift_now]
as
select *
from Shift where deleted='false' AND convert(time, getdate()) >= time_start and convert(time, getdate()) <= time_end
go

