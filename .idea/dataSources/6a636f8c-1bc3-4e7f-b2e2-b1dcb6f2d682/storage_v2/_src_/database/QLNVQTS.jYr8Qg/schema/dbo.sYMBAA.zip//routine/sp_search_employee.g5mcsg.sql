CREATE proc sp_search_employee	 @filter nvarchar(100)
as
begin
	select *
	from Employee
	where active='true' AND 
		first_name + ' ' + last_name like '%'+@filter+'%'
	
	
end
go

