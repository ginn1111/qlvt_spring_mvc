create proc sp_get_all_time_table_filter_by_name @filter nvarchar(100)
as
begin
DECLARE @from_date date
exec sp_get_date_start @from_date out;
WITH months(MonthNumber) AS
(
    SELECT 0
    UNION ALL
    SELECT MonthNumber+1
    FROM months
    WHERE MonthNumber < 27
)

select id_shift, date=CONVERT(Date, dateadd(day,MonthNumber, @from_date)), num_of_emp
into #TMP
from (select * from months) L, (select * from Shift where deleted='false') S

select TT.* from TimeTable TT
		inner join #TMP TMP on TMP.date = TT.date and TMP.id_shift = TT.id_shift
		inner join (
			select id_shift, date
					from (select id_shift, date, id_emp=iif(id_emp_alter is null, id_emp, id_emp_alter) from TimeTable) T
					inner join (select id_emp from Employee where active='true' and last_name like N'Thuận') E on E.id_emp = T.id_emp
		) T on T.date = TT.date and T.id_shift = TT.id_shift
order by id_shift, date

drop table #TMP
end
go

