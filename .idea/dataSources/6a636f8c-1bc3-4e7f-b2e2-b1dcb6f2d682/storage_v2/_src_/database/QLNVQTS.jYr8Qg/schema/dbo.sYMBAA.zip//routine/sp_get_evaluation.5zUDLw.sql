CREATE proc [dbo].[sp_get_evaluation] @id_emp nvarchar(10), @is_all bit
as begin
DECLARE @from_date datetime;
exec sp_get_date_start @from_date out;
WITH months(MonthNumber) AS
(
    SELECT 0
    UNION ALL
    SELECT MonthNumber+1
    FROM months
    WHERE MonthNumber < 27
)

select tmp.*
	into #TMP
	from (
		select id_shift, date=CONVERT(Date, dateadd(day,MonthNumber, @from_date)), num_of_emp
		from (select * from months) L, (select * from Shift where deleted='false') S
	) tmp inner join (select distinct id_shift, date from TimeTable where date >= @from_date)
		TT on TT.id_shift = tmp.id_shift and TT.date = tmp.date

select id_date_shift=convert(nvarchar, date) + convert(nvarchar, id_shift),id_shift, date, num
, id_emp, description=ISNULL(EE.description,'')--, id_manager=ISNULL(id_manager,'')
into #TMP2
from (
	select *
	from TimeTable where date >= @from_date AND id_emp=@id_emp
	) TT LEFT JOIN (
		select id_time_table, description, id_manager, num 
		from  (
				select id_time_table, id_manager, id_fault, num 
				from Evaluate
			) E INNER JOIN (select id_fault, description from Fault) F ON F.id_fault = E.id_fault
		) EE
	ON EE.id_time_table = TT.id_time_table 

select id=TMP.id_date_shift+ISNULL(description,''), TMP.id_shift, TMP.date, description, num=ISNULL(num,1)
into #TMP3
from #TMP2 TMP2 RIGHT JOIN (
			select id_date_shift=convert(nvarchar, date) + convert(nvarchar, id_shift), date, id_shift 
			from #TMP
		) TMP
ON TMP.id_date_shift = TMP2.id_date_shift 
order by id_shift, date

if @is_all = 'false'
	begin
		if GETDATE() >= @from_date AND GETDATE() < @from_date + 7
			select * From #TMP3 WHERE date between @from_date and @from_date + 6 ORDER BY id_shift, date
		else if GETDATE() >= @from_date + 7 AND GETDATE() < @from_date + 14
			select * From #TMP3 WHERE date between @from_date + 7 and @from_date + 13 ORDER BY id_shift, date
		else if GETDATE() >= @from_date + 14 AND GETDATE() < @from_date + 21
			select * From #TMP3 WHERE date between @from_date + 14 and @from_date + 20 ORDER BY id_shift, date
		else 
			select * From #TMP3 WHERE date between @from_date + 21 and @from_date + 27 ORDER BY id_shift, date
			 -- @from_date and @from_date + 6
			 -- @from_date + 7 and @from_date + 13
			 -- @from_date + 14 and @from_date + 20
			 -- @from_date + 21 and @from_date + 27
	end
else 
	select * from #TMP3 ORDER BY id_shift, date

DROP TABLE #TMP
DROP TABLE #TMP2
DROP TABLE #TMP3
end

go

