CREATE proc [dbo].[sp_get_num_of_shift_of_all_emp_part_time]
as

begin
DECLARE @from_date date
	exec sp_get_date_start @from_date out
	;WITH months(MonthNumber) AS
	(
		SELECT 0
		UNION ALL
		SELECT MonthNumber+1
		FROM months
		WHERE MonthNumber < 27
	)

	select tmp.*
	into #TMP
	from (
		select id_shift, date=CONVERT(Date, dateadd(day,MonthNumber, @from_date)), num_of_emp
		from (select * from months) L, (select * from Shift where deleted='false') S
	) tmp inner join (select distinct id_shift, date from TimeTable where date >= @from_date)
		TT on TT.id_shift = tmp.id_shift and TT.date = tmp.date

select E.id_emp, first_name, last_name, num_of_shift=isnull(num_of_shift,0)
into #TT_TMP
from (
	select id_emp, first_name, last_name, id_position
	from Employee
	where active = 'true'
) E join (
	select id_position, position_name
	from Position
	where is_fulltime = 'false'
) P on E.id_position = P.id_position
left join (
	select id_emp=isnull(id_emp_alter, id_emp), num_of_shift=isnull(count(id_emp),0)
	from TimeTable T inner join #TMP Tmp
	on T.date = Tmp.date and T.id_shift = Tmp.id_shift
	group by id_emp, id_emp_alter
) TT on TT.id_emp = E.id_emp
group by E.id_emp, first_name, last_name, num_of_shift

select id_emp, first_name, last_name, num_of_shift=sum(#TT_TMP.num_of_shift)
from #TT_TMP
group by id_emp, first_name, last_name
order by id_emp

drop table #TMP
drop table #TT_TMP

end
go

