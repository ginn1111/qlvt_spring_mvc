
CREATE proc sp_get_shift_now @id_shift int out
as
begin
	declare @from_date datetime
	exec sp_get_date_start @from_date out
	
select @id_shift=id_shift
from Shift where deleted='false' 
	AND convert(time, getdate()) >= time_start 
	AND convert(time, getdate()) <= time_end 
	AND id_shift in (select id_shift from TimeTable where date >= @from_date)
end
return
go

