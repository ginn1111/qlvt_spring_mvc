CREATE proc [dbo].[sp_statist_evaluation_of_emp] @month int, @year int
as
begin

select id_emp=isnull(id_emp_alter, id_emp), id_time_table, id_shift, date
into #TT_TMP
from TimeTable 
where month(date) = @month AND year(date)=@year

select id_statist_evaluation_of_emp=id_evaluate, E.id_emp, num, description, name, date
from (
		select *
		from Employee
		where active = 1
) E inner join #TT_TMP TT_TMP on TT_TMP.id_emp = E.id_emp
inner join (
	select id_evaluate, id_time_table, num, f.description
	from Evaluate Eval inner join Fault F on F.id_fault = Eval.id_fault
) Eval on Eval.id_time_table = TT_TMP.id_time_table
inner join (select id_shift, name from Shift where deleted='false') S
on S.id_shift = TT_TMP.id_shift
order by id_emp, date DESC, name ASC

drop table #TT_TMP
end
go

