CREATE proc [dbo].[sp_get_lack_of_emp] @filter nvarchar(10)
as
begin

DECLARE @from_date datetime;
exec sp_get_date_start @from_date out;
;WITH months(MonthNumber) AS
(
    SELECT 0
    UNION ALL
    SELECT MonthNumber+1
    FROM months
    WHERE MonthNumber < 27
)

select tmp.*
	into #TMP
	from (
		select id_shift, date=CONVERT(Date, dateadd(day,MonthNumber, @from_date)), name, num_of_emp
		from (select * from months) L, (select * from Shift where deleted='false') S
	) tmp inner join (select distinct id_shift, date from TimeTable where date >= @from_date)
		TT on TT.id_shift = tmp.id_shift and TT.date = tmp.date

	declare @num_of_ft_emp int
	select @num_of_ft_emp=count(*)
	from (
		select id_position
		from Employee where active='true'
	) E inner join (
		select id_position
		from Position
		where is_fulltime = 1
	) P on E.id_position = P.id_position

select id_lack_of_emp=convert(nvarchar, #TMP.id_shift)+convert(nvarchar, #TMP.date), 
		name, #TMP.date, amount = num_of_emp - (count(id_time_table) - @num_of_ft_emp)
into #TMP2
from #TMP
left join TimeTable T on T.id_shift = #TMP.id_shift AND T.date = #TMP.date
group by #TMP.id_shift, #TMP.date, num_of_emp, name , name having num_of_emp - (count(id_time_table) - @num_of_ft_emp) > 0
order by #TMP.id_shift, #TMP.date


if @filter = ''
	select * from #TMP2
else
	select * from #TMP2 where date like @filter

drop table #TMP
drop table #TMP2
end

go

