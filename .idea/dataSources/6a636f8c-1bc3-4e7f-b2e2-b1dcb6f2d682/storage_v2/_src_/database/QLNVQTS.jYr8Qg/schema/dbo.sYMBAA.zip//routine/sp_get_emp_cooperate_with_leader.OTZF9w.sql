
CREATE proc [dbo].[sp_get_emp_cooperate_with_leader] 
@id_shift int, @date nvarchar(10), @id_leader nvarchar(10), @id_up_task int
as
begin
	select id_time_table, TT.id_emp, date
	from (
				select id_time_table, id_emp=iif(id_emp_alter is null, id_emp, id_emp_alter), date
				from TimeTable
				where date = @date AND id_shift = @id_shift AND 
					id_time_table not in (select id_time_table from Work where id_up_task = @id_up_task)
			) TT
	inner join (
					select id_emp
					from Employee where active = 'true'
				) E on TT.id_emp = E.id_emp
	
end
go

