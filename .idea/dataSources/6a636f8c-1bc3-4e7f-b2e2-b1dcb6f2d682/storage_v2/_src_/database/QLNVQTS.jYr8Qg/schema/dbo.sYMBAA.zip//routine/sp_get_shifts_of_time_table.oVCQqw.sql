CREATE proc sp_get_shifts_of_time_table
as
begin
DECLARE @from_date datetime;
exec sp_get_date_start @from_date out;
WITH months(MonthNumber) AS
(
    SELECT 0
    UNION ALL
    SELECT MonthNumber+1
    FROM months
    WHERE MonthNumber < 27
)


select id_shift, date=CONVERT(Date, dateadd(day,MonthNumber, @from_date))
into #TMP
from (select * from months) L, (select * from Shift where deleted='false') S

select distinct S.id_shift, name, time_start, time_end, basic_salary, num_of_emp, deleted
from TimeTable TT inner join #TMP TMP on TT.id_shift=TMP.id_shift AND TT.date=TMP.date
inner join (select * from shift where deleted='false') S on S.id_shift=TT.id_shift
drop table #TMP
end
go

