create view v_get_year_start
as
select year_start=min(year(date))
from Salary
go

