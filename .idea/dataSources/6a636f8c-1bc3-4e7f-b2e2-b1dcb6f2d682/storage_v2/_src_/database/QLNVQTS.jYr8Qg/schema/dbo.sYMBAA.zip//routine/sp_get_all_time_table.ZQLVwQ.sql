CREATE proc [dbo].[sp_get_all_time_table]
as
begin

DECLARE @from_date datetime;
exec sp_get_date_start @from_date out;
WITH months(MonthNumber) AS
(
    SELECT 0
    UNION ALL
    SELECT MonthNumber+1
    FROM months
    WHERE MonthNumber < 27
)

-- Liet ke tat ca cac ca lam trong ngay
select id_shift, date=CONVERT(Date, dateadd(day,MonthNumber, @from_date))
into #TMP
from (select * from months) L, (select * from Shift where deleted='false') S

select TT.* from TimeTable TT inner join #TMP TMP 
	on TT.id_shift = TMP.id_shift and TT.date = TMP.date 
	order by date DESC, id_shift ASC

drop table #TMP
end
go

