CREATE trigger [dbo].[tr_insert_work] on [dbo].[Work]
for insert
as
begin
	declare @id_up_task int, @id_time_table int, @date_ut date,
		@date_tt date, @id_shift_ut int, @id_shift_tt int

	select @date_tt = date, @id_shift_tt = id_shift
	from inserted I
	inner join TimeTable T on T.id_time_table = I.id_time_table

	select @date_ut = date, @id_shift_ut = id_shift
	from inserted I
	inner join UpTasks UT on UT.id_up_task = I.id_up_task

	if @date_tt <> @date_ut OR @id_shift_tt <> @id_shift_ut
	begin
		delete from Work where id_time_table = (select id_time_table from inserted)
			AND id_up_task = (select id_up_task from inserted)
		raiserror('Invalid date and shift for insert in table work', 16, 1)
	end
end
go

