
CREATE proc [dbo].[sp_get_all_time_table_filter_by_date] @filter nvarchar(10)
as
begin


	select TT.*
		from TimeTable TT
		inner join (select id_shift from Shift where deleted='false') S
		on S.id_shift = TT.id_shift
		where date LIKE @filter 
		order by date DESC, id_shift ASC

end
go

