
CREATE function [dbo].[udf_get_emp_of_shift] (@date date, @id_shift int)
returns table
as
return (select * from TimeTable
	where date=@date AND id_shift=@id_shift)
go

