
CREATE proc [dbo].[sp_get_emp_of_shift_now] @id_shift int
as
begin
select id_time_table, id_shift, date, 
	id_emp=iif(id_emp_alter is null, id_emp, id_emp_alter), id_emp_alter=null, 
	description 
from udf_get_emp_of_shift(getdate(), @id_shift)
end
go

