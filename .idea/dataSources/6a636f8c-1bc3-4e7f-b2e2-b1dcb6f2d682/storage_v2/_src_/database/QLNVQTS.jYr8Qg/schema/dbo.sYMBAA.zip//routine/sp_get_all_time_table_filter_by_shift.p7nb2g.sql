create proc [dbo].[sp_get_all_time_table_filter_by_shift] @filter nvarchar(50)
as
begin
DECLARE @from_date date
exec sp_get_date_start @from_date out;
WITH months(MonthNumber) AS
(
    SELECT 0
    UNION ALL
    SELECT MonthNumber+1
    FROM months
    WHERE MonthNumber < 27
)

select id_shift, date=CONVERT(Date, dateadd(day,MonthNumber, @from_date)), num_of_emp
into #TMP
from (select * from months) L, (select * from Shift where deleted='false') S

set dateformat dmy;

	select TT.* from TimeTable TT
		inner join #TMP TMP on TMP.date = TT.date and TMP.id_shift = TT.id_shift
		where TT.id_shift in (select id_shift from Shift where name LIKE @filter)
		order by TT.id_shift, TT.date

drop table #TMP
end
go

