CREATE proc [dbo].[sp_get_time_table_of_emp] @id_emp nvarchar(10), @is_all bit
as
begin
DECLARE @from_date datetime;
exec sp_get_date_start @from_date out;
WITH months(MonthNumber) AS
(
    SELECT 0
    UNION ALL
    SELECT MonthNumber+1
    FROM months
    WHERE MonthNumber < 27
)

-- Liet ke tat ca cac ca lam trong ngay

select tmp.*
	into #TMP
	from (
		select id_shift, date=CONVERT(Date, dateadd(day,MonthNumber, @from_date)), num_of_emp
		from (select * from months) L, (select * from Shift where deleted='false') S
	) tmp inner join (select distinct id_shift, date from TimeTable where date >= @from_date)
		TT on TT.id_shift = tmp.id_shift and TT.date = tmp.date

-- Liet ke lich lam cua nhan vien co ma @id_emp

SELECT id_shift, date, id_emp=@id_emp, job=ISNULL(job,'')
INTO #TMP2
FROM work
INNER JOIN (SELECT id_up_task, id_task FROM UpTasks) UT
ON UT.id_up_task = Work.id_up_task
INNER JOIN (SELECT id_task, job FROM Task) T
ON T.id_task = UT.id_task
RIGHT JOIN (
		SELECT id_time_table, id_shift, date 
		FROM TimeTable 
		WHERE id_emp = @id_emp AND date in (select date from #TMP)
	) TT
ON TT.id_time_table = Work.id_time_table

-- Liet ke tat ca lich lam (neu lam -> job IS NOT NULL, khong lam -> job IS NULL, khong co job -> job = '')

SELECT id_status_shift=tmp.id_status_shift+ISNULL(job,''), id_shift, date, job
INTO #TMP3
FROM (
		SELECT id_status_shift=CONVERT(nvarchar, date)+CONVERT(nvarchar,id_shift), id_shift, date from #TMP 
	) tmp LEFT JOIN (
		SELECT id_status_shift=CONVERT(nvarchar, date)+CONVERT(nvarchar,id_shift), job FROM #TMP2
	) Tmp2 ON tmp2.id_status_shift = tmp.id_status_shift

if @is_all = 'false'
	begin
		if GETDATE() >= @from_date AND GETDATE() < @from_date + 7
			select * From #TMP3 WHERE date between @from_date and @from_date + 6 ORDER BY id_shift, date
		else if GETDATE() >= @from_date + 7 AND GETDATE() < @from_date + 14
			select * From #TMP3 WHERE date between @from_date + 7 and @from_date + 13 ORDER BY id_shift, date
		else if GETDATE() >= @from_date + 14 AND GETDATE() < @from_date + 21
			select * From #TMP3 WHERE date between @from_date + 14 and @from_date + 20 ORDER BY id_shift, date
		else
			select * From #TMP3 WHERE date between @from_date + 21 and @from_date + 27 ORDER BY id_shift, date
			 -- @from_date and @from_date + 6
			 -- @from_date + 7 and @from_date + 13
			 -- @from_date + 14 and @from_date + 20
			 -- @from_date + 21 and @from_date + 27
	end
else 
	select * from #TMP3 ORDER BY id_shift, date

DROP TABLE #TMP
DROP TABLE #TMP2
DROP TABLE #TMP3
end

go

