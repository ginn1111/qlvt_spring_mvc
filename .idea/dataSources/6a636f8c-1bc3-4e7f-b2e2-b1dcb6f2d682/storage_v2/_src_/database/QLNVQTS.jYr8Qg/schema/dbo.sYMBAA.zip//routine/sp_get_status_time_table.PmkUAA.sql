
CREATE proc [dbo].[sp_get_status_time_table] @id_emp nvarchar(10)
as
begin


	DECLARE @from_date date
	exec sp_get_date_start @from_date out
	;WITH months(MonthNumber) AS
	(
		SELECT 0
		UNION ALL
		SELECT MonthNumber+1
		FROM months
		WHERE MonthNumber < 27
	)
	select tmp.*
	into #TMP
	from (
		select id_shift, date=CONVERT(Date, dateadd(day,MonthNumber, @from_date)), num_of_emp
		from (select * from months) L, (select * from Shift where deleted='false') S
	) tmp inner join (select distinct id_shift, date from TimeTable where date >= @from_date)
		TT on TT.id_shift = tmp.id_shift and TT.date = tmp.date

	declare @num_of_ft_emp int
	select @num_of_ft_emp=count(*)
	from (
		select id_position
		from Employee where active='true'
	) E inner join (
		select id_position
		from Position
		where is_fulltime = 1
	) P on E.id_position = P.id_position

	select date, T.id_shift
	into #TMP2
	from (
		select  id_shift, date, contain= CASE 
			WHEN @id_emp in (select id_emp=iif(id_emp_alter is null, id_emp, id_emp_alter) 
				from TimeTable TT
				where TT.id_shift=TMP.id_shift AND TT.date=TMP.date) 
			THEN 'true' ELSE 'false' END,
			num_add=count(*)
		from (
				select T.date, T.id_shift, id_emp=iif(id_emp_alter is null, id_emp, id_emp_alter)
				from TimeTable TT
				inner join #TMP T on T.date = TT.date and T.id_shift = TT.id_shift
			) TMP 
		group by id_shift, date
	) T inner join (select id_shift, num_of_emp from shift) S on S.id_shift = T.id_shift
	where  num_add-@num_of_ft_emp >= num_of_emp  OR contain='true'

	select id_status_shift=CONVERT(nvarchar, date)+CONVERT(nvarchar, id_shift)
		, id_shift
		, date
		, status = CASE 
			WHEN CONVERT(nvarchar, date)+CONVERT(nvarchar, id_shift) 
				in (select CONVERT(nvarchar, date)+CONVERT(nvarchar, id_shift) from #TMP2)  
				OR date < getdate() 
			THEN 'true' 
			ELSE 'false' 
			END
	from #TMP order by id_shift, date
	drop table #TMP2
	drop table #TMP
end

go

