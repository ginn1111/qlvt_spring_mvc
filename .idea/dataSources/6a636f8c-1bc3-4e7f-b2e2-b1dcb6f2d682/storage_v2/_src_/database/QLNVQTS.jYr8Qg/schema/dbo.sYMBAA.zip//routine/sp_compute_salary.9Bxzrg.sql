CREATE proc [dbo].[sp_compute_salary] @month int, @year int
as
begin

select id_emp, fix_salary = sum(amount)
into #TMP_FIX_SALARY
from (
	select T.id_emp, amount=count(id_time_table)*basic_salary*coefficient
	from ( 
			select id_emp=iif(id_emp_alter is not null, id_emp_alter, id_emp), id_shift, id_time_table 
			from TimeTable 
			where month(date) = @month AND year(date) = @year
		) T
	inner join Shift S on S.id_shift = T.id_shift
	inner join (select id_emp, id_position from Employee) E on E.id_emp = T.id_emp
	inner join Position P on P.id_position = E.id_position
	
	group by  T.id_shift, basic_salary, T.id_emp, coefficient
) TMP 
group by id_emp

merge into Salary as target
using (
		select FS.id_emp, date=convert(date, concat(@year,'-', @month, '-01')), 
		salary=FS.fix_salary + isnull(sum(num*basic_salary*percent_of_salary/100),0)
	from (
			select id_emp=iif(id_emp_alter is null, id_emp, id_emp_alter), id_shift, id_time_table 
			from TimeTable
			where month(date) = @month AND year(date) = @year
		) T
	inner join Shift S on S.id_shift = T.id_shift -- basic_salary
	inner join Evaluate E on E.id_time_table = T.id_time_table -- num
	inner join Fault F on F.id_fault = E.id_fault -- percent of salary
	right join #TMP_FIX_SALARY FS on FS.id_emp = T.id_emp
	group by FS.id_emp, fix_salary
) as source
on year(target.date) = year(source.date) AND month(target.date) = month(source.date) AND target.id_emp = source.id_emp
when matched then
	update set target.salary = source.salary
when not matched then
	insert (id_emp, date, salary) values (source.id_emp, source.date, source.salary);
drop table #TMP_FIX_SALARY

end

go

