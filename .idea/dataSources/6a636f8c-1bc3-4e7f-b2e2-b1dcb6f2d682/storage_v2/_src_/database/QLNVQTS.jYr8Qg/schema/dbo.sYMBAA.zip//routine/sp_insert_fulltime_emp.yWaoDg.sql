

CREATE proc [dbo].[sp_insert_fulltime_emp] @from_date date
as
begin
	;WITH months(MonthNumber) AS
	(
		SELECT 0
		UNION ALL
		SELECT MonthNumber+1
		FROM months
		WHERE MonthNumber < 27
	)

	select id_shift, date=CONVERT(Date, dateadd(day,MonthNumber, @from_date)), id_emp
	into #TMP
	from (select * from months) L, (select * from Shift where deleted='false') S, 
		(	select id_emp
			from (select id_position from Position where is_fulltime = 1) P
			inner join (select id_emp, id_position from Employee where active='true')
			E on E.id_position = P.id_position
		) E

	set xact_abort on
	begin tran
	begin try
	
	delete from TimeTable 
	where id_emp in (
			select id_emp
			from (
				select id_emp, id_position
				from Employee
				where active='true'
			) E inner join (
				select id_position
				from Position
				where is_fulltime = 1
			) P on E.id_position = P.id_position
		) AND date >= @from_date

	insert into TimeTable (id_shift, date, id_emp)
	select id_shift, date, id_emp
	from #TMP
	commit
	end try
	begin catch
	rollback
	end catch

	--merge into TimeTable as target
	--using #TMP as source
	--on target.date = source.date and target.id_shift = source.id_shift
	--when not matched then
	--insert (id_shift, date, id_emp) values (source.id_shift, source.date, source.id_emp);
	
	drop table #TMP
end

go

